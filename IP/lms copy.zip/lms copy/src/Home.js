import {useState,useEffect} from "react";
import axios from "axios";
import "./Home.css";
import {useNavigate} from "react-router-dom";
function Home(){
    const[books,setBooks]=useState([]);
    const navigate=useNavigate();
    const fetchbooks=()=>{axios.get("http://localhost:5000/books").then(res=>setBooks(res.data))};
    useEffect(()=>{fetchbooks();},[]);
    const deleteBook = (id) => {if (window.confirm("Are you sure you want to delete?")) {
        axios.delete(`http://localhost:5000/books/${id}`)
        .then(() => fetchbooks());
    }
    };
    return (
    <div className="container">
      <h2>Book List</h2>
      <table border="1">
        <thead>
          <tr>
            <th>ID</th><th>Title</th><th>Author</th><th>Year</th><th>Actions</th>
          </tr>
        </thead>

        <tbody>
          {books.map(b => (
            <tr key={b.id}>
              <td>{b.id}</td>
              <td>{b.title}</td>
              <td>{b.author}</td>
              <td>{b.year}</td>
              <td>
                <button onClick={() => navigate(`/edit/${b.id}`)}>Edit</button>
                <button onClick={() => deleteBook(b.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

    </div>
  );
}
export default Home;