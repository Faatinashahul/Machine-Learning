import {Link} from "react-router-dom";
import "./Navbar.css";
function Navbar(){
    return(
       <nav className="navbar">
        <h2>LMS</h2>
        <div className="nav-links">
            <Link to="/">Home</Link>
            <Link to="/add">Add Book</Link>
        </div>
        </nav>
    );
}
export default Navbar;

