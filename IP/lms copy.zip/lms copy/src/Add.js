import {useState,useEffect} from "react";
import axios from "axios";
import "./Add.css";
import { useNavigate } from "react-router-dom";
function Add(){
    const[book,setBook]=useState({title:"",author:"",year:""});
    const navigate=useNavigate();
    const handleChange=(e)=>{
        setBook({...book,[e.target.name]:e.target.value});
    };
    const handleSubmit=()=>{
        axios.post("http://localhost:5000/books",book).then(()=>navigate("/"));
    };
    return(
        <div className="form-container">
            <h2>AddBook</h2>
            <input name="title" placeholder="Title" onChange={handleChange} />
            <input name="author" placeholder="Author" onChange={handleChange} />
            <input name="year" placeholder="Year" onChange={handleChange} />
            <button onClick={handleSubmit}>Add</button>
        </div>
    );
}

export default Add;