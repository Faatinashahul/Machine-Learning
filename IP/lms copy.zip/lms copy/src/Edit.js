import {useState,useEffect} from "react";
import axios from "axios";
import "./Add.css";
import { useNavigate,useParams } from "react-router-dom";
function Edit(){
    const{id}=useParams();
    const navigate=useNavigate();
    const[book,setBook]=useState({title:"",author:"",year:""});
    const [message, setMessage] = useState("");
    const handleChange=(e)=>{
        setBook({...book,[e.target.name]:e.target.value});
    };
    useEffect(() => {
        axios.get("http://localhost:5000/books")
        .then(res => {
            const found = res.data.find(b => b.id == id);
            setBook(found);
        });
    }, [id]);

    const handleUpdate = () => {
        axios.put(`http://localhost:5000/books/${id}`, book)
            .then(() => {
            setMessage("Book updated successfully!");
            setTimeout(() => navigate("/"), 1500);
            });
    };

    return (
        <div className="form-container">
        <h2>Edit Book</h2>
        <p style={{ color: "green" }}>{message}</p>
        <input name="title" value={book.title} onChange={handleChange} />
        <input name="author" value={book.author} onChange={handleChange} />
        <input name="year" value={book.year} onChange={handleChange} />
        <button onClick={handleUpdate}>Update</button>
        </div>
    );
}

export default Edit;