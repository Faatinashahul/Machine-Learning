import { BrowserRouter as Router,Routes,Route}from "react-router-dom";
import Navbar from "./Navbar";
import Home from "./Home";
import Add from "./Add";
import Edit from "./Edit";
function App(params) {
  return(
    <Router>
      <Navbar/>
      <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/add" element={<Add/>}/>
        <Route path="/edit/:id" element={<Edit />} />
      </Routes>
    </Router>
  );
}
export default App;