const express=require("express");
const mysql=require("mysql2");
const cors=require("cors");

const app=express();
app.use(cors());
app.use(express.json())

const db=mysql.createConnection(
    {host:"localhost",user:"root",password:"Faa2023-2027",database:"library_db"}
);

app.get("/",(req,res)=>{res.send("Backend is working")});

app.get("/books",(req,res)=>
    {db.query("SELECT * FROM books",
        (err,result)=>{if (err) return res.json(err);
        return res.json(result)
    });
});

app.post("/books",(req,res)=>{
    const {title,author,year}=req.body;
    db.query("INSERT INTO books(title ,author,year) VALUES (?,?,?)",
        [title,author,year],
        (err)=>{if(err) return res.json(err);
        res.json("Book Added")});
});

app.delete("/books/:id", (req, res) => {
  console.log("Deleting ID:", req.params.id); 

  db.query("DELETE FROM books WHERE id=?",
    [req.params.id],
    (err, result) => {
      if (err) {
        console.log(err);
        return res.json(err);
      }
      console.log("Deleted rows:", result.affectedRows); 
      res.json("Book deleted");
    }
  );
});

app.put("/books/:id",(req,res)=>{
    const {title,author,year}=req.body;
    db.query("UPDATE books SET title=?, author=?, year=? WHERE id=?",[title,author,year,req.params.id],(err) => {
      if (err) return res.json(err);
      res.json("Updated");
    }
  );
});
app.listen(5000,()=>console.log("Server running on port 5000"));